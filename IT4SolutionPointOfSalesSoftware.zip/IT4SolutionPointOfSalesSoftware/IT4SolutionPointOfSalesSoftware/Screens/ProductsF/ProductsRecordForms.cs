﻿using ClosedXML.Excel;
using IT4SolutionPointOfSalesSoftware.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    public partial class ProductsRecordForms : MetroFramework.Forms.MetroForm
    {
        private int getSupplierID;

        public ProductsRecordForms()
        {
            InitializeComponent();
            Search_grid.DataSource = getData();
            loadAllProductsIntoDataGridView();


        }
        void deleteProduct()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("deleteProcedure", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@idDelete", getSupplierID);

                        cmd.Parameters.Add("@ret", SqlDbType.Int);
                        cmd.Parameters["@ret"].Direction = ParameterDirection.Output;

                        con.Open();
                        int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                        int ret = Convert.ToInt32(cmd.Parameters["@ret"].Value);

                        if (ret > 0)
                        {
                            MessageBox.Show("Product  Information Is Deleteed !   ");
                            Search_grid.Rows.Clear();
                            Search_grid.Columns.Clear();
                            Search_grid.DataSource = null;

                            Search_grid.DataSource = null;

                            Search_grid.Rows.Clear();
                            Search_grid.Columns.Clear();

                            Search_grid.DataSource = getData();
                            loadAllProductsIntoDataGridView();

                        }
                        else
                        {
                            MessageBox.Show("No Product To delete try again....");
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                Search_grid.DataSource = getData();
                loadAllProductsIntoDataGridView();
                //     MessageBox.Show("Product  Is Already Deleted"+ex);
            }
        }
        private void ProductsRecordForms_Load(object sender, EventArgs e)
        {
        }

        private void loadAllProductsIntoDataGridView()
        {

            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            btn.HeaderText = "Delete";
            btn.Text = "Delete";
            btn.Name = "btn";
            btn.UseColumnTextForButtonValue = true;
            Search_grid.Columns.Add(btn);

        }

        private DataTable getData()
        {
            Search_grid.Columns.Clear();
            DataTable tdRecord = new DataTable();
            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("ups_Products_LoadAllProductsForDataGridView", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    tdRecord.Load(sdr);
                }
            }
            return tdRecord;
        }

        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void Search_grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int Row = e.RowIndex;
            try
            {

                if (Row > -1)
                {
                    getSupplierID = Convert.ToInt32(Search_grid.Rows[Row].Cells["ProductID"].Value.ToString());
                    deleteProduct();
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DashboardForm dbf = new DashboardForm();
            dbf.Show();
        }

        private void txt_Product_Name_Click(object sender, EventArgs e)
        {


        }
        DataTable tdRecord = new DataTable();


        private DataTable GetProductByProductID()
        {
            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("ups_Products_LoadAllProductsByProductName", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", txt_Product_Name.Text.Trim());
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    tdRecord.Load(sdr);
                }
            }
            return tdRecord;
        }
    }
}

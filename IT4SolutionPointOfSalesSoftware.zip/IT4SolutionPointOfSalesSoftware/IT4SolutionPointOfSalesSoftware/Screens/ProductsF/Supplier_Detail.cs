﻿using IT4SolutionPointOfSalesSoftware.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    public partial class Supplier_Detail : MetroFramework.Forms.MetroForm
    {
        private object getSupplierID;

        public Supplier_Detail()
        {
            InitializeComponent();
        }
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            grid_supplier.DataSource = null;
            grid_supplier.Rows.Clear();
            grid_supplier.Columns.Clear();
            try
            {
                using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("Select * from supplier", con))
                    {
                        con.Open();
                        SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                        adpt.Fill(dt);
                        grid_supplier.DataSource = dt;
                        addButton();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



            return dt;
        }
        void addButton()
        {
            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            grid_supplier.Columns.Add(btn);
            btn.HeaderText = "View Data";
            btn.Text = "Display";
            btn.Name = "btn";
            btn.UseColumnTextForButtonValue = true;
        }

        private void Supplier_Detail_Load(object sender, EventArgs e)
        {

            GetData();
        }

        private void btn_supplierInsert_Click(object sender, EventArgs e)
        {
          
            
                try
                {

                    using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("ipl_suppliers", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@Supplier_Name", txt_supplierName.Text);
                            cmd.Parameters.AddWithValue("@Supplier_Address", txt_supplierAddress.Text);
                            cmd.Parameters.AddWithValue("@Supplier_CellNo", txt_supplierCell.Text);

                            cmd.Parameters.Add("@return", SqlDbType.Int);
                            cmd.Parameters["@return"].Direction = ParameterDirection.Output;

                            con.Open();
                            int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                            int ret = Convert.ToInt32(cmd.Parameters["@return"].Value);
                            if (ret > 0)
                            {
                                MessageBox.Show("Supplier Details Is Inserted !   ");
                            }
                            else
                            {
                                MessageBox.Show("Supplier Details Is Not Inserted !   try again....");
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" SupplierName " + txt_supplierName.Text + " Is Already Inserted");
                }
          
        }
        private void btn_supplierUpdate_Click(object sender, EventArgs e)
        {
            
            if (txt_supplierName.Text.Length > 0)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("upl_suppliers", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@Supplier_Name", txt_supplierName.Text);
                            cmd.Parameters.AddWithValue("@Supplier_Address", txt_supplierAddress.Text);
                            cmd.Parameters.AddWithValue("@Supplier_CellNo", txt_supplierCell.Text);
                            cmd.Parameters.AddWithValue("@SupplierID", getSupplierID);
                            cmd.Parameters.Add("@return", SqlDbType.Int);
                            cmd.Parameters["@return"].Direction = ParameterDirection.Output;

                            con.Open();
                            int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                            int ret = Convert.ToInt32(cmd.Parameters["@return"].Value);
                            if (ret > 0)
                            {
                                MessageBox.Show("Supplier Information Is Updated !   ");
                                btn_supplierUpdate.Enabled = false;
                                txt_supplierName.Text = "";
                                txt_supplierAddress.Text = "";
                                txt_supplierCell.Text = "";
                                GetData();

                            }
                            else
                            {
                                MessageBox.Show("No Supplier Detail Is Updated !   try again....");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Supplier Name " + txt_supplierName.Text + " Is Already Updated");
                }
            }
            else
            {
                MessageBox.Show("Supplier Name Should Not Be Null");
            }
        }

      
        private void txt_supplierCell_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
          
        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int Row = e.RowIndex;
            if (Row > -1 && (Row + 1) != grid_supplier.Rows.Count)
            {
                btn_supplierUpdate.Enabled = true;
                txt_supplierName.Text = grid_supplier.Rows[Row].Cells[1].Value.ToString();
                txt_supplierAddress.Text = grid_supplier.Rows[Row].Cells[2].Value.ToString();
                txt_supplierCell.Text = grid_supplier.Rows[Row].Cells[3].Value.ToString();

                getSupplierID = Convert.ToInt32(grid_supplier.Rows[Row].Cells[0].Value.ToString());
            }
            else
            {

                btn_supplierUpdate.Enabled = false;
            }
        }

        private void txt_searchNameSupplier_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DashboardForm fd = new DashboardForm();
            fd.Show();
        }

        private void txt_searchNameSupplier_TextChanged(object sender, EventArgs e)
        {
            (grid_supplier.DataSource as DataTable).DefaultView.RowFilter = string.Format("[Supplier Name] like '%{0}%'", txt_searchNameSupplier.Text);
        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
        
    
    

﻿namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    partial class Customer_Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer_Management));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_close = new MetroFramework.Controls.MetroButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_searchNamecustomer = new MetroFramework.Controls.MetroTextBox();
            this.txt_customeraddress = new System.Windows.Forms.RichTextBox();
            this.grid_customer = new MetroFramework.Controls.MetroGrid();
            this.txt_customerCell = new System.Windows.Forms.MaskedTextBox();
            this.btn_customerUpdate = new MetroFramework.Controls.MetroButton();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.btn_customerInsert = new MetroFramework.Controls.MetroButton();
            this.txt_customername = new MetroFramework.Controls.MetroTextBox();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grid_customer)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Navy;
            this.btn_close.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_close.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_close.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_close, "btn_close");
            this.btn_close.Name = "btn_close";
            this.btn_close.UseCustomBackColor = true;
            this.btn_close.UseCustomForeColor = true;
            this.btn_close.UseSelectable = true;
            this.btn_close.UseStyleColors = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // txt_searchNamecustomer
            // 
            // 
            // 
            // 
            this.txt_searchNamecustomer.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.txt_searchNamecustomer.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location")));
            this.txt_searchNamecustomer.CustomButton.Name = "";
            this.txt_searchNamecustomer.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size")));
            this.txt_searchNamecustomer.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_searchNamecustomer.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex")));
            this.txt_searchNamecustomer.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_searchNamecustomer.CustomButton.UseSelectable = true;
            this.txt_searchNamecustomer.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible")));
            this.txt_searchNamecustomer.Lines = new string[0];
            resources.ApplyResources(this.txt_searchNamecustomer, "txt_searchNamecustomer");
            this.txt_searchNamecustomer.MaxLength = 32767;
            this.txt_searchNamecustomer.Name = "txt_searchNamecustomer";
            this.txt_searchNamecustomer.PasswordChar = '\0';
            this.txt_searchNamecustomer.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_searchNamecustomer.SelectedText = "";
            this.txt_searchNamecustomer.SelectionLength = 0;
            this.txt_searchNamecustomer.SelectionStart = 0;
            this.txt_searchNamecustomer.ShortcutsEnabled = true;
            this.txt_searchNamecustomer.UseSelectable = true;
            this.txt_searchNamecustomer.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_searchNamecustomer.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txt_customeraddress
            // 
            resources.ApplyResources(this.txt_customeraddress, "txt_customeraddress");
            this.txt_customeraddress.Name = "txt_customeraddress";
            // 
            // grid_customer
            // 
            this.grid_customer.AllowUserToDeleteRows = false;
            this.grid_customer.AllowUserToResizeRows = false;
            this.grid_customer.BackgroundColor = System.Drawing.Color.Navy;
            this.grid_customer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_customer.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_customer.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_customer.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grid_customer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_customer.DefaultCellStyle = dataGridViewCellStyle2;
            this.grid_customer.EnableHeadersVisualStyles = false;
            resources.ApplyResources(this.grid_customer, "grid_customer");
            this.grid_customer.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_customer.Name = "grid_customer";
            this.grid_customer.ReadOnly = true;
            this.grid_customer.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_customer.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grid_customer.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_customer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_customer.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_customer_CellContentClick);
            // 
            // txt_customerCell
            // 
            resources.ApplyResources(this.txt_customerCell, "txt_customerCell");
            this.txt_customerCell.Name = "txt_customerCell";
            // 
            // btn_customerUpdate
            // 
            this.btn_customerUpdate.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.btn_customerUpdate, "btn_customerUpdate");
            this.btn_customerUpdate.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_customerUpdate.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_customerUpdate.ForeColor = System.Drawing.SystemColors.Window;
            this.btn_customerUpdate.Name = "btn_customerUpdate";
            this.btn_customerUpdate.UseCustomBackColor = true;
            this.btn_customerUpdate.UseCustomForeColor = true;
            this.btn_customerUpdate.UseSelectable = true;
            this.btn_customerUpdate.UseStyleColors = true;
            this.btn_customerUpdate.Click += new System.EventHandler(this.btn_customerUpdate_Click);
            // 
            // metroLabel3
            // 
            resources.ApplyResources(this.metroLabel3, "metroLabel3");
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Name = "metroLabel3";
            // 
            // metroLabel2
            // 
            resources.ApplyResources(this.metroLabel2, "metroLabel2");
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Name = "metroLabel2";
            // 
            // metroLabel1
            // 
            resources.ApplyResources(this.metroLabel1, "metroLabel1");
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Name = "metroLabel1";
            // 
            // btn_customerInsert
            // 
            this.btn_customerInsert.BackColor = System.Drawing.Color.Navy;
            this.btn_customerInsert.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_customerInsert.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_customerInsert.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_customerInsert, "btn_customerInsert");
            this.btn_customerInsert.Name = "btn_customerInsert";
            this.btn_customerInsert.UseCustomBackColor = true;
            this.btn_customerInsert.UseCustomForeColor = true;
            this.btn_customerInsert.UseSelectable = true;
            this.btn_customerInsert.UseStyleColors = true;
            this.btn_customerInsert.Click += new System.EventHandler(this.btn_customerInsert_Click);
            // 
            // txt_customername
            // 
            // 
            // 
            // 
            this.txt_customername.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.txt_customername.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location1")));
            this.txt_customername.CustomButton.Name = "";
            this.txt_customername.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size1")));
            this.txt_customername.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_customername.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex1")));
            this.txt_customername.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_customername.CustomButton.UseSelectable = true;
            this.txt_customername.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible1")));
            this.txt_customername.Lines = new string[0];
            resources.ApplyResources(this.txt_customername, "txt_customername");
            this.txt_customername.MaxLength = 32767;
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.PasswordChar = '\0';
            this.txt_customername.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_customername.SelectedText = "";
            this.txt_customername.SelectionLength = 0;
            this.txt_customername.SelectionStart = 0;
            this.txt_customername.ShortcutsEnabled = true;
            this.txt_customername.UseSelectable = true;
            this.txt_customername.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_customername.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txt_customername.Click += new System.EventHandler(this.txt_customername_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Navy;
            this.metroPanel1.Controls.Add(this.pictureBox8);
            this.metroPanel1.Controls.Add(this.label4);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            resources.ApplyResources(this.metroPanel1, "metroPanel1");
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox8, "pictureBox8");
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.TabStop = false;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Name = "label4";
            // 
            // Customer_Management
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_searchNamecustomer);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.grid_customer);
            this.Controls.Add(this.txt_customerCell);
            this.Controls.Add(this.btn_customerUpdate);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.btn_customerInsert);
            this.Controls.Add(this.txt_customername);
            this.Movable = false;
            this.Name = "Customer_Management";
            this.Resizable = false;
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.None;
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Right;
            this.Theme = MetroFramework.MetroThemeStyle.Default;
            this.Load += new System.EventHandler(this.Customer_Management_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid_customer)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton btn_close;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroTextBox txt_searchNamecustomer;
        private System.Windows.Forms.RichTextBox txt_customeraddress;
        private MetroFramework.Controls.MetroGrid grid_customer;
        private System.Windows.Forms.MaskedTextBox txt_customerCell;
        private MetroFramework.Controls.MetroButton btn_customerUpdate;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton btn_customerInsert;
        private MetroFramework.Controls.MetroTextBox txt_customername;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox8;
    }
}
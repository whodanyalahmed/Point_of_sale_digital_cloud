﻿namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    partial class Supplier_Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Supplier_Detail));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txt_supplierName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txt_supplierCell = new System.Windows.Forms.MaskedTextBox();
            this.btn_supplierInsert = new MetroFramework.Controls.MetroButton();
            this.btn_supplierUpdate = new MetroFramework.Controls.MetroButton();
            this.grid_supplier = new MetroFramework.Controls.MetroGrid();
            this.txt_supplierAddress = new System.Windows.Forms.RichTextBox();
            this.txt_searchNameSupplier = new MetroFramework.Controls.MetroTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.grid_supplier)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_supplierName
            // 
            // 
            // 
            // 
            this.txt_supplierName.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.txt_supplierName.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location")));
            this.txt_supplierName.CustomButton.Name = "";
            this.txt_supplierName.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size")));
            this.txt_supplierName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_supplierName.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex")));
            this.txt_supplierName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_supplierName.CustomButton.UseSelectable = true;
            this.txt_supplierName.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible")));
            this.txt_supplierName.Lines = new string[0];
            resources.ApplyResources(this.txt_supplierName, "txt_supplierName");
            this.txt_supplierName.MaxLength = 32767;
            this.txt_supplierName.Name = "txt_supplierName";
            this.txt_supplierName.PasswordChar = '\0';
            this.txt_supplierName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_supplierName.SelectedText = "";
            this.txt_supplierName.SelectionLength = 0;
            this.txt_supplierName.SelectionStart = 0;
            this.txt_supplierName.ShortcutsEnabled = true;
            this.txt_supplierName.UseSelectable = true;
            this.txt_supplierName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_supplierName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            resources.ApplyResources(this.metroLabel1, "metroLabel1");
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Name = "metroLabel1";
            // 
            // metroLabel2
            // 
            resources.ApplyResources(this.metroLabel2, "metroLabel2");
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Name = "metroLabel2";
            // 
            // metroLabel3
            // 
            resources.ApplyResources(this.metroLabel3, "metroLabel3");
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Name = "metroLabel3";
            // 
            // txt_supplierCell
            // 
            resources.ApplyResources(this.txt_supplierCell, "txt_supplierCell");
            this.txt_supplierCell.Name = "txt_supplierCell";
            this.txt_supplierCell.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txt_supplierCell_MaskInputRejected);
            // 
            // btn_supplierInsert
            // 
            this.btn_supplierInsert.BackColor = System.Drawing.Color.Navy;
            this.btn_supplierInsert.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_supplierInsert.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_supplierInsert.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_supplierInsert, "btn_supplierInsert");
            this.btn_supplierInsert.Name = "btn_supplierInsert";
            this.btn_supplierInsert.UseCustomBackColor = true;
            this.btn_supplierInsert.UseCustomForeColor = true;
            this.btn_supplierInsert.UseSelectable = true;
            this.btn_supplierInsert.UseStyleColors = true;
            this.btn_supplierInsert.Click += new System.EventHandler(this.btn_supplierInsert_Click);
            // 
            // btn_supplierUpdate
            // 
            this.btn_supplierUpdate.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.btn_supplierUpdate, "btn_supplierUpdate");
            this.btn_supplierUpdate.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_supplierUpdate.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_supplierUpdate.ForeColor = System.Drawing.SystemColors.Window;
            this.btn_supplierUpdate.Name = "btn_supplierUpdate";
            this.btn_supplierUpdate.UseCustomBackColor = true;
            this.btn_supplierUpdate.UseCustomForeColor = true;
            this.btn_supplierUpdate.UseSelectable = true;
            this.btn_supplierUpdate.UseStyleColors = true;
            this.btn_supplierUpdate.Click += new System.EventHandler(this.btn_supplierUpdate_Click);
            // 
            // grid_supplier
            // 
            this.grid_supplier.AllowUserToDeleteRows = false;
            this.grid_supplier.AllowUserToResizeRows = false;
            this.grid_supplier.BackgroundColor = System.Drawing.Color.Navy;
            this.grid_supplier.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_supplier.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_supplier.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_supplier.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grid_supplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_supplier.DefaultCellStyle = dataGridViewCellStyle2;
            this.grid_supplier.EnableHeadersVisualStyles = false;
            resources.ApplyResources(this.grid_supplier, "grid_supplier");
            this.grid_supplier.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_supplier.Name = "grid_supplier";
            this.grid_supplier.ReadOnly = true;
            this.grid_supplier.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_supplier.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grid_supplier.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_supplier.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_supplier.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.metroGrid1_CellContentClick);
            // 
            // txt_supplierAddress
            // 
            resources.ApplyResources(this.txt_supplierAddress, "txt_supplierAddress");
            this.txt_supplierAddress.Name = "txt_supplierAddress";
            // 
            // txt_searchNameSupplier
            // 
            // 
            // 
            // 
            this.txt_searchNameSupplier.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.txt_searchNameSupplier.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location1")));
            this.txt_searchNameSupplier.CustomButton.Name = "";
            this.txt_searchNameSupplier.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size1")));
            this.txt_searchNameSupplier.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_searchNameSupplier.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex1")));
            this.txt_searchNameSupplier.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_searchNameSupplier.CustomButton.UseSelectable = true;
            this.txt_searchNameSupplier.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible1")));
            this.txt_searchNameSupplier.Lines = new string[0];
            resources.ApplyResources(this.txt_searchNameSupplier, "txt_searchNameSupplier");
            this.txt_searchNameSupplier.MaxLength = 32767;
            this.txt_searchNameSupplier.Name = "txt_searchNameSupplier";
            this.txt_searchNameSupplier.PasswordChar = '\0';
            this.txt_searchNameSupplier.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_searchNameSupplier.SelectedText = "";
            this.txt_searchNameSupplier.SelectionLength = 0;
            this.txt_searchNameSupplier.SelectionStart = 0;
            this.txt_searchNameSupplier.ShortcutsEnabled = true;
            this.txt_searchNameSupplier.UseSelectable = true;
            this.txt_searchNameSupplier.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_searchNameSupplier.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txt_searchNameSupplier.TextChanged += new System.EventHandler(this.txt_searchNameSupplier_TextChanged);
            this.txt_searchNameSupplier.Click += new System.EventHandler(this.txt_searchNameSupplier_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Navy;
            this.metroPanel1.Controls.Add(this.pictureBox3);
            this.metroPanel1.Controls.Add(this.label4);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            resources.ApplyResources(this.metroPanel1, "metroPanel1");
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Name = "label4";
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.Navy;
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.metroButton1, "metroButton1");
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // Supplier_Detail
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_searchNameSupplier);
            this.Controls.Add(this.txt_supplierAddress);
            this.Controls.Add(this.grid_supplier);
            this.Controls.Add(this.txt_supplierCell);
            this.Controls.Add(this.btn_supplierUpdate);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.btn_supplierInsert);
            this.Controls.Add(this.txt_supplierName);
            this.Movable = false;
            this.Name = "Supplier_Detail";
            this.Resizable = false;
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.Supplier_Detail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid_supplier)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox txt_supplierName;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.MaskedTextBox txt_supplierCell;
        private MetroFramework.Controls.MetroButton btn_supplierInsert;
        private MetroFramework.Controls.MetroButton btn_supplierUpdate;
        private MetroFramework.Controls.MetroGrid grid_supplier;
        private System.Windows.Forms.RichTextBox txt_supplierAddress;
        private MetroFramework.Controls.MetroTextBox txt_searchNameSupplier;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}
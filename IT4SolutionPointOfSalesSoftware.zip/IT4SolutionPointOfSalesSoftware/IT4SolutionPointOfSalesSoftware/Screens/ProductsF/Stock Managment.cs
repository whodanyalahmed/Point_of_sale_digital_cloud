﻿using IT4SolutionPointOfSalesSoftware.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    public partial class Stock_Managment :  MetroFramework.Forms.MetroForm
    {
        public Stock_Managment()
        {
            InitializeComponent();
            comboboxDataFill();
           Metro_Gridview.DataSource = GetSizesData();
            comboboxdataSupplier();

        }
        List<String> categoryID = new List<string>();
        List<double> Price = new List<double>();
        List<String> supplierID = new List<string>();
        void comboboxDataFill()
        {
            combobox_pcategory.Items.Clear();
            categoryID.Clear();
            combobox_pcategory.Items.Add("Select Product");
            categoryID.Add("Select Product ");
            combobox_pcategory.SelectedIndex = 0;
            Price.Add(0);
            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from  [dbo].[Products]", con))
                {
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        combobox_pcategory.Items.Add(sdr["Name"].ToString());
                        categoryID.Add(sdr["ProductID"].ToString());
                        Price.Add(Convert.ToDouble(sdr["SalesPrice"].ToString()));
                    }

                }
            }

        }
        void comboboxdataSupplier()
        {
            combobox_psupplier.Items.Clear();
            supplierID.Clear();
            combobox_psupplier.Items.Add("Select Customer Name");
            supplierID.Add("Select Customer Name");
            combobox_psupplier.SelectedIndex = 0;
            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from [dbo].[Customers]", con))
                {
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        combobox_psupplier.Items.Add(sdr["Name"].ToString());
                        supplierID.Add(sdr["CustomerID"].ToString());

                    }

                }
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm frm = new DashboardForm();
            frm.Show();
        }

        private void Purchase_price_Click(object sender, EventArgs e)
        {
           
        }

        private void metroTextBox2_Click(object sender, EventArgs e)
        {

        }

        private void Purchase_price_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int indexs = combobox_pcategory.SelectedIndex;
                Double prices = Price[indexs];
                Sales_price.Text = (Convert.ToDouble(Purchase_price.Text.ToString()) * prices).ToString();
            }
            catch (Exception ex)
            {

            }
        }

        private void metroTextBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Double prices = Convert.ToDouble( Sales_price.Text);
                metroTextBox3.Text = (prices - ((prices* Convert.ToDouble(metroTextBox2.Text.ToString())) /100)).ToString();
            }
            catch (Exception ex)
            {

            }
        }
        private DataTable GetSizesData()
        {
            DataTable dtsizes = new DataTable();

            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("select * from [dbo].[SalesOrders] ", con))
                {
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtsizes.Load(sdr);
                    con.Close();

                }
            }

            return dtsizes;
        }

        private void metroTextBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Double prices = Convert.ToDouble(metroTextBox3.Text);
                metroTextBox5.Text = (prices - Convert.ToDouble(metroTextBox4.Text.ToString())).ToString();
            }
            catch (Exception ex)
            {

            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {

            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[SalesOrders]           ([InvoiceDate]           ,[CustomerID]          ,[Quantity]           ,[GrandTotal],[Discount]           ,[Balance])     VALUES           (getdate()           ,@cid,@qty,@gt,@dis,@bal); ", con))
                {
                    con.Open();
                    cmd.Parameters.AddWithValue("@cid", supplierID[combobox_psupplier.SelectedIndex]);
                    cmd.Parameters.AddWithValue("@qty", Purchase_price.Text);
                    cmd.Parameters.AddWithValue("@gt", metroTextBox3.Text);
                    cmd.Parameters.AddWithValue("@dis", metroTextBox2.Text);
                    cmd.Parameters.AddWithValue("@bal", metroTextBox5.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Invoice Has Been Generated For CUstomer " + combobox_psupplier.SelectedItem);con.Close();
                    Metro_Gridview.DataSource = GetSizesData();
                }
            }
        }
    }
}

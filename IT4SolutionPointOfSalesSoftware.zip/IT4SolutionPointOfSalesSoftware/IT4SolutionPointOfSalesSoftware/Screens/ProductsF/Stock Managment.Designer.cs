﻿namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    partial class Stock_Managment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Stock_Managment));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.combobox_psupplier = new System.Windows.Forms.ComboBox();
            this.combobox_pcategory = new System.Windows.Forms.ComboBox();
            this.btn_close = new MetroFramework.Controls.MetroButton();
            this.Purchase_price = new MetroFramework.Controls.MetroTextBox();
            this.Sales_price = new MetroFramework.Controls.MetroTextBox();
            this.lbl_sprice = new MetroFramework.Controls.MetroLabel();
            this.lbl_costprice = new MetroFramework.Controls.MetroLabel();
            this.lbl_psupplier = new MetroFramework.Controls.MetroLabel();
            this.lbl_pcategory = new MetroFramework.Controls.MetroLabel();
            this.Metro_Gridview = new MetroFramework.Controls.MetroGrid();
            this.btn_save = new MetroFramework.Controls.MetroButton();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox4 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox5 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Metro_Gridview)).BeginInit();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroLabel1.Location = new System.Drawing.Point(434, 89);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(133, 19);
            this.metroLabel1.TabIndex = 32;
            this.metroLabel1.Text = "Search Your Product";
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseCustomForeColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(191, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(262, 31);
            this.label4.TabIndex = 4;
            this.label4.Text = "#Stock Management";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(107, -4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 69);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(276, 1);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(434, 111);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(298, 23);
            this.metroTextBox1.TabIndex = 26;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Navy;
            this.metroPanel1.Controls.Add(this.label4);
            this.metroPanel1.Controls.Add(this.pictureBox2);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(-2, 7);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(803, 65);
            this.metroPanel1.TabIndex = 31;
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // combobox_psupplier
            // 
            this.combobox_psupplier.FormattingEnabled = true;
            this.combobox_psupplier.Location = new System.Drawing.Point(137, 140);
            this.combobox_psupplier.Name = "combobox_psupplier";
            this.combobox_psupplier.Size = new System.Drawing.Size(235, 21);
            this.combobox_psupplier.TabIndex = 19;
            // 
            // combobox_pcategory
            // 
            this.combobox_pcategory.FormattingEnabled = true;
            this.combobox_pcategory.Location = new System.Drawing.Point(137, 104);
            this.combobox_pcategory.Name = "combobox_pcategory";
            this.combobox_pcategory.Size = new System.Drawing.Size(235, 21);
            this.combobox_pcategory.TabIndex = 18;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Navy;
            this.btn_close.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_close.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_close.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_close.Location = new System.Drawing.Point(617, 350);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(115, 29);
            this.btn_close.TabIndex = 28;
            this.btn_close.Text = "Close";
            this.btn_close.UseCustomBackColor = true;
            this.btn_close.UseCustomForeColor = true;
            this.btn_close.UseSelectable = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // Purchase_price
            // 
            // 
            // 
            // 
            this.Purchase_price.CustomButton.Image = null;
            this.Purchase_price.CustomButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Purchase_price.CustomButton.Location = new System.Drawing.Point(176, 1);
            this.Purchase_price.CustomButton.Name = "";
            this.Purchase_price.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Purchase_price.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Purchase_price.CustomButton.TabIndex = 1;
            this.Purchase_price.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Purchase_price.CustomButton.UseSelectable = true;
            this.Purchase_price.CustomButton.Visible = false;
            this.Purchase_price.Lines = new string[0];
            this.Purchase_price.Location = new System.Drawing.Point(137, 180);
            this.Purchase_price.MaxLength = 32767;
            this.Purchase_price.Name = "Purchase_price";
            this.Purchase_price.PasswordChar = '\0';
            this.Purchase_price.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Purchase_price.SelectedText = "";
            this.Purchase_price.SelectionLength = 0;
            this.Purchase_price.SelectionStart = 0;
            this.Purchase_price.ShortcutsEnabled = true;
            this.Purchase_price.Size = new System.Drawing.Size(198, 23);
            this.Purchase_price.TabIndex = 20;
            this.Purchase_price.UseSelectable = true;
            this.Purchase_price.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Purchase_price.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.Purchase_price.TextChanged += new System.EventHandler(this.Purchase_price_TextChanged);
            this.Purchase_price.Click += new System.EventHandler(this.Purchase_price_Click);
            // 
            // Sales_price
            // 
            // 
            // 
            // 
            this.Sales_price.CustomButton.Image = null;
            this.Sales_price.CustomButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Sales_price.CustomButton.Location = new System.Drawing.Point(176, 1);
            this.Sales_price.CustomButton.Name = "";
            this.Sales_price.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Sales_price.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Sales_price.CustomButton.TabIndex = 1;
            this.Sales_price.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Sales_price.CustomButton.UseSelectable = true;
            this.Sales_price.CustomButton.Visible = false;
            this.Sales_price.Enabled = false;
            this.Sales_price.Lines = new string[0];
            this.Sales_price.Location = new System.Drawing.Point(137, 216);
            this.Sales_price.MaxLength = 32767;
            this.Sales_price.Name = "Sales_price";
            this.Sales_price.PasswordChar = '\0';
            this.Sales_price.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Sales_price.SelectedText = "";
            this.Sales_price.SelectionLength = 0;
            this.Sales_price.SelectionStart = 0;
            this.Sales_price.ShortcutsEnabled = true;
            this.Sales_price.Size = new System.Drawing.Size(198, 23);
            this.Sales_price.TabIndex = 22;
            this.Sales_price.UseSelectable = true;
            this.Sales_price.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Sales_price.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lbl_sprice
            // 
            this.lbl_sprice.AutoSize = true;
            this.lbl_sprice.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_sprice.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_sprice.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_sprice.Location = new System.Drawing.Point(15, 218);
            this.lbl_sprice.Name = "lbl_sprice";
            this.lbl_sprice.Size = new System.Drawing.Size(91, 25);
            this.lbl_sprice.TabIndex = 29;
            this.lbl_sprice.Text = "Total Price";
            this.lbl_sprice.UseCustomBackColor = true;
            this.lbl_sprice.UseCustomForeColor = true;
            // 
            // lbl_costprice
            // 
            this.lbl_costprice.AutoSize = true;
            this.lbl_costprice.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_costprice.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_costprice.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_costprice.Location = new System.Drawing.Point(15, 184);
            this.lbl_costprice.Name = "lbl_costprice";
            this.lbl_costprice.Size = new System.Drawing.Size(44, 25);
            this.lbl_costprice.TabIndex = 27;
            this.lbl_costprice.Text = "QTY";
            this.lbl_costprice.UseCustomBackColor = true;
            this.lbl_costprice.UseCustomForeColor = true;
            // 
            // lbl_psupplier
            // 
            this.lbl_psupplier.AutoSize = true;
            this.lbl_psupplier.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_psupplier.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_psupplier.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_psupplier.Location = new System.Drawing.Point(15, 140);
            this.lbl_psupplier.Name = "lbl_psupplier";
            this.lbl_psupplier.Size = new System.Drawing.Size(89, 25);
            this.lbl_psupplier.TabIndex = 24;
            this.lbl_psupplier.Text = "Customer";
            this.lbl_psupplier.UseCustomBackColor = true;
            this.lbl_psupplier.UseCustomForeColor = true;
            // 
            // lbl_pcategory
            // 
            this.lbl_pcategory.AutoSize = true;
            this.lbl_pcategory.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_pcategory.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_pcategory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_pcategory.Location = new System.Drawing.Point(15, 104);
            this.lbl_pcategory.Name = "lbl_pcategory";
            this.lbl_pcategory.Size = new System.Drawing.Size(82, 25);
            this.lbl_pcategory.TabIndex = 23;
            this.lbl_pcategory.Text = "Products";
            this.lbl_pcategory.UseCustomBackColor = true;
            this.lbl_pcategory.UseCustomForeColor = true;
            // 
            // Metro_Gridview
            // 
            this.Metro_Gridview.AllowUserToResizeRows = false;
            this.Metro_Gridview.BackgroundColor = System.Drawing.Color.Navy;
            this.Metro_Gridview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Metro_Gridview.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.Metro_Gridview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Metro_Gridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Metro_Gridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Metro_Gridview.DefaultCellStyle = dataGridViewCellStyle2;
            this.Metro_Gridview.EnableHeadersVisualStyles = false;
            this.Metro_Gridview.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.Metro_Gridview.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Metro_Gridview.Location = new System.Drawing.Point(434, 140);
            this.Metro_Gridview.Name = "Metro_Gridview";
            this.Metro_Gridview.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Metro_Gridview.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Metro_Gridview.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Metro_Gridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Metro_Gridview.Size = new System.Drawing.Size(298, 204);
            this.Metro_Gridview.TabIndex = 30;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.Navy;
            this.btn_save.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_save.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_save.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_save.Location = new System.Drawing.Point(138, 418);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(198, 48);
            this.btn_save.TabIndex = 25;
            this.btn_save.Text = "Create Invoice";
            this.btn_save.UseCustomBackColor = true;
            this.btn_save.UseCustomForeColor = true;
            this.btn_save.UseSelectable = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // metroTextBox2
            // 
            // 
            // 
            // 
            this.metroTextBox2.CustomButton.Image = null;
            this.metroTextBox2.CustomButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.metroTextBox2.CustomButton.Location = new System.Drawing.Point(176, 1);
            this.metroTextBox2.CustomButton.Name = "";
            this.metroTextBox2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox2.CustomButton.TabIndex = 1;
            this.metroTextBox2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox2.CustomButton.UseSelectable = true;
            this.metroTextBox2.CustomButton.Visible = false;
            this.metroTextBox2.Lines = new string[0];
            this.metroTextBox2.Location = new System.Drawing.Point(137, 264);
            this.metroTextBox2.MaxLength = 32767;
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.PasswordChar = '\0';
            this.metroTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox2.SelectedText = "";
            this.metroTextBox2.SelectionLength = 0;
            this.metroTextBox2.SelectionStart = 0;
            this.metroTextBox2.ShortcutsEnabled = true;
            this.metroTextBox2.Size = new System.Drawing.Size(198, 23);
            this.metroTextBox2.TabIndex = 33;
            this.metroTextBox2.UseSelectable = true;
            this.metroTextBox2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox2.TextChanged += new System.EventHandler(this.metroTextBox2_TextChanged);
            this.metroTextBox2.Click += new System.EventHandler(this.metroTextBox2_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroLabel2.Location = new System.Drawing.Point(15, 266);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(82, 25);
            this.metroLabel2.TabIndex = 34;
            this.metroLabel2.Text = "Discount";
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseCustomForeColor = true;
            // 
            // metroTextBox3
            // 
            // 
            // 
            // 
            this.metroTextBox3.CustomButton.Image = null;
            this.metroTextBox3.CustomButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.metroTextBox3.CustomButton.Location = new System.Drawing.Point(176, 1);
            this.metroTextBox3.CustomButton.Name = "";
            this.metroTextBox3.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox3.CustomButton.TabIndex = 1;
            this.metroTextBox3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox3.CustomButton.UseSelectable = true;
            this.metroTextBox3.CustomButton.Visible = false;
            this.metroTextBox3.Enabled = false;
            this.metroTextBox3.Lines = new string[0];
            this.metroTextBox3.Location = new System.Drawing.Point(138, 306);
            this.metroTextBox3.MaxLength = 32767;
            this.metroTextBox3.Name = "metroTextBox3";
            this.metroTextBox3.PasswordChar = '\0';
            this.metroTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox3.SelectedText = "";
            this.metroTextBox3.SelectionLength = 0;
            this.metroTextBox3.SelectionStart = 0;
            this.metroTextBox3.ShortcutsEnabled = true;
            this.metroTextBox3.Size = new System.Drawing.Size(198, 23);
            this.metroTextBox3.TabIndex = 35;
            this.metroTextBox3.UseSelectable = true;
            this.metroTextBox3.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox3.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroLabel3.Location = new System.Drawing.Point(15, 308);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(110, 25);
            this.metroLabel3.TabIndex = 36;
            this.metroLabel3.Text = "Net Amount";
            this.metroLabel3.UseCustomBackColor = true;
            this.metroLabel3.UseCustomForeColor = true;
            // 
            // metroTextBox4
            // 
            // 
            // 
            // 
            this.metroTextBox4.CustomButton.Image = null;
            this.metroTextBox4.CustomButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.metroTextBox4.CustomButton.Location = new System.Drawing.Point(176, 1);
            this.metroTextBox4.CustomButton.Name = "";
            this.metroTextBox4.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox4.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox4.CustomButton.TabIndex = 1;
            this.metroTextBox4.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox4.CustomButton.UseSelectable = true;
            this.metroTextBox4.CustomButton.Visible = false;
            this.metroTextBox4.Lines = new string[0];
            this.metroTextBox4.Location = new System.Drawing.Point(138, 348);
            this.metroTextBox4.MaxLength = 32767;
            this.metroTextBox4.Name = "metroTextBox4";
            this.metroTextBox4.PasswordChar = '\0';
            this.metroTextBox4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox4.SelectedText = "";
            this.metroTextBox4.SelectionLength = 0;
            this.metroTextBox4.SelectionStart = 0;
            this.metroTextBox4.ShortcutsEnabled = true;
            this.metroTextBox4.Size = new System.Drawing.Size(198, 23);
            this.metroTextBox4.TabIndex = 37;
            this.metroTextBox4.UseSelectable = true;
            this.metroTextBox4.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox4.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox4.TextChanged += new System.EventHandler(this.metroTextBox4_TextChanged);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroLabel4.Location = new System.Drawing.Point(15, 354);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(45, 25);
            this.metroLabel4.TabIndex = 38;
            this.metroLabel4.Text = "Paid";
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseCustomForeColor = true;
            // 
            // metroTextBox5
            // 
            // 
            // 
            // 
            this.metroTextBox5.CustomButton.Image = null;
            this.metroTextBox5.CustomButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.metroTextBox5.CustomButton.Location = new System.Drawing.Point(176, 1);
            this.metroTextBox5.CustomButton.Name = "";
            this.metroTextBox5.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox5.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox5.CustomButton.TabIndex = 1;
            this.metroTextBox5.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox5.CustomButton.UseSelectable = true;
            this.metroTextBox5.CustomButton.Visible = false;
            this.metroTextBox5.Enabled = false;
            this.metroTextBox5.Lines = new string[0];
            this.metroTextBox5.Location = new System.Drawing.Point(137, 389);
            this.metroTextBox5.MaxLength = 32767;
            this.metroTextBox5.Name = "metroTextBox5";
            this.metroTextBox5.PasswordChar = '\0';
            this.metroTextBox5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox5.SelectedText = "";
            this.metroTextBox5.SelectionLength = 0;
            this.metroTextBox5.SelectionStart = 0;
            this.metroTextBox5.ShortcutsEnabled = true;
            this.metroTextBox5.Size = new System.Drawing.Size(198, 23);
            this.metroTextBox5.TabIndex = 39;
            this.metroTextBox5.UseSelectable = true;
            this.metroTextBox5.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox5.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroLabel5.Location = new System.Drawing.Point(15, 391);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(91, 25);
            this.metroLabel5.TabIndex = 40;
            this.metroLabel5.Text = "Remaning";
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.UseCustomForeColor = true;
            // 
            // Stock_Managment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 495);
            this.Controls.Add(this.metroTextBox5);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroTextBox4);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroTextBox3);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroTextBox2);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroTextBox1);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.combobox_psupplier);
            this.Controls.Add(this.combobox_pcategory);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.Purchase_price);
            this.Controls.Add(this.Sales_price);
            this.Controls.Add(this.lbl_sprice);
            this.Controls.Add(this.lbl_costprice);
            this.Controls.Add(this.lbl_psupplier);
            this.Controls.Add(this.lbl_pcategory);
            this.Controls.Add(this.Metro_Gridview);
            this.Controls.Add(this.btn_save);
            this.Name = "Stock_Managment";
            this.Text = "Stock_Managment";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Metro_Gridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.ComboBox combobox_psupplier;
        private System.Windows.Forms.ComboBox combobox_pcategory;
        private MetroFramework.Controls.MetroButton btn_close;
        private MetroFramework.Controls.MetroTextBox Purchase_price;
        private MetroFramework.Controls.MetroTextBox Sales_price;
        private MetroFramework.Controls.MetroLabel lbl_sprice;
        private MetroFramework.Controls.MetroLabel lbl_costprice;
        private MetroFramework.Controls.MetroLabel lbl_psupplier;
        private MetroFramework.Controls.MetroLabel lbl_pcategory;
        private MetroFramework.Controls.MetroGrid Metro_Gridview;
        private MetroFramework.Controls.MetroButton btn_save;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox metroTextBox3;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox metroTextBox4;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox metroTextBox5;
        private MetroFramework.Controls.MetroLabel metroLabel5;
    }
}
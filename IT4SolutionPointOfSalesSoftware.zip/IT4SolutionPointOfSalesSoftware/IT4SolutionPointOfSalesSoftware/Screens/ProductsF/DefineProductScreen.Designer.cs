﻿namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    partial class DefineProductScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DefineProductScreen));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_save = new MetroFramework.Controls.MetroButton();
            this.Metro_Gridview = new MetroFramework.Controls.MetroGrid();
            this.txt_pname = new MetroFramework.Controls.MetroTextBox();
            this.lbl_pname = new MetroFramework.Controls.MetroLabel();
            this.lbl_pcategory = new MetroFramework.Controls.MetroLabel();
            this.lbl_psupplier = new MetroFramework.Controls.MetroLabel();
            this.lbl_costprice = new MetroFramework.Controls.MetroLabel();
            this.lbl_sprice = new MetroFramework.Controls.MetroLabel();
            this.Sales_price = new MetroFramework.Controls.MetroTextBox();
            this.Purchase_price = new MetroFramework.Controls.MetroTextBox();
            this.btn_close = new MetroFramework.Controls.MetroButton();
            this.combobox_pcategory = new System.Windows.Forms.ComboBox();
            this.combobox_psupplier = new System.Windows.Forms.ComboBox();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.Metro_Gridview)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.Navy;
            this.btn_save.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_save.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_save.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            resources.ApplyResources(this.btn_save, "btn_save");
            this.btn_save.Name = "btn_save";
            this.btn_save.UseCustomBackColor = true;
            this.btn_save.UseCustomForeColor = true;
            this.btn_save.UseSelectable = true;
            this.btn_save.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // Metro_Gridview
            // 
            this.Metro_Gridview.AllowUserToResizeRows = false;
            this.Metro_Gridview.BackgroundColor = System.Drawing.Color.Navy;
            this.Metro_Gridview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Metro_Gridview.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.Metro_Gridview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Metro_Gridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Metro_Gridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Metro_Gridview.DefaultCellStyle = dataGridViewCellStyle2;
            this.Metro_Gridview.EnableHeadersVisualStyles = false;
            resources.ApplyResources(this.Metro_Gridview, "Metro_Gridview");
            this.Metro_Gridview.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Metro_Gridview.Name = "Metro_Gridview";
            this.Metro_Gridview.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Metro_Gridview.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Metro_Gridview.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Metro_Gridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Metro_Gridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Metro_Gridview_CellContentClick);
            // 
            // txt_pname
            // 
            // 
            // 
            // 
            this.txt_pname.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.txt_pname.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location")));
            this.txt_pname.CustomButton.Name = "";
            this.txt_pname.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size")));
            this.txt_pname.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_pname.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex")));
            this.txt_pname.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_pname.CustomButton.UseSelectable = true;
            this.txt_pname.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible")));
            this.txt_pname.Lines = new string[0];
            resources.ApplyResources(this.txt_pname, "txt_pname");
            this.txt_pname.MaxLength = 32767;
            this.txt_pname.Name = "txt_pname";
            this.txt_pname.PasswordChar = '\0';
            this.txt_pname.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_pname.SelectedText = "";
            this.txt_pname.SelectionLength = 0;
            this.txt_pname.SelectionStart = 0;
            this.txt_pname.ShortcutsEnabled = true;
            this.txt_pname.UseSelectable = true;
            this.txt_pname.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_pname.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txt_pname.Click += new System.EventHandler(this.txt_pname_Click);
            // 
            // lbl_pname
            // 
            resources.ApplyResources(this.lbl_pname, "lbl_pname");
            this.lbl_pname.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_pname.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_pname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_pname.Name = "lbl_pname";
            this.lbl_pname.UseCustomBackColor = true;
            this.lbl_pname.UseCustomForeColor = true;
            this.lbl_pname.Click += new System.EventHandler(this.lbl_pname_Click);
            // 
            // lbl_pcategory
            // 
            resources.ApplyResources(this.lbl_pcategory, "lbl_pcategory");
            this.lbl_pcategory.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_pcategory.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_pcategory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_pcategory.Name = "lbl_pcategory";
            this.lbl_pcategory.UseCustomBackColor = true;
            this.lbl_pcategory.UseCustomForeColor = true;
            // 
            // lbl_psupplier
            // 
            resources.ApplyResources(this.lbl_psupplier, "lbl_psupplier");
            this.lbl_psupplier.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_psupplier.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_psupplier.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_psupplier.Name = "lbl_psupplier";
            this.lbl_psupplier.UseCustomBackColor = true;
            this.lbl_psupplier.UseCustomForeColor = true;
            // 
            // lbl_costprice
            // 
            resources.ApplyResources(this.lbl_costprice, "lbl_costprice");
            this.lbl_costprice.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_costprice.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_costprice.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_costprice.Name = "lbl_costprice";
            this.lbl_costprice.UseCustomBackColor = true;
            this.lbl_costprice.UseCustomForeColor = true;
            // 
            // lbl_sprice
            // 
            resources.ApplyResources(this.lbl_sprice, "lbl_sprice");
            this.lbl_sprice.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lbl_sprice.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbl_sprice.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_sprice.Name = "lbl_sprice";
            this.lbl_sprice.UseCustomBackColor = true;
            this.lbl_sprice.UseCustomForeColor = true;
            // 
            // Sales_price
            // 
            // 
            // 
            // 
            this.Sales_price.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.Sales_price.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location1")));
            this.Sales_price.CustomButton.Name = "";
            this.Sales_price.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size1")));
            this.Sales_price.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Sales_price.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex1")));
            this.Sales_price.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Sales_price.CustomButton.UseSelectable = true;
            this.Sales_price.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible1")));
            this.Sales_price.Lines = new string[0];
            resources.ApplyResources(this.Sales_price, "Sales_price");
            this.Sales_price.MaxLength = 32767;
            this.Sales_price.Name = "Sales_price";
            this.Sales_price.PasswordChar = '\0';
            this.Sales_price.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Sales_price.SelectedText = "";
            this.Sales_price.SelectionLength = 0;
            this.Sales_price.SelectionStart = 0;
            this.Sales_price.ShortcutsEnabled = true;
            this.Sales_price.UseSelectable = true;
            this.Sales_price.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Sales_price.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Purchase_price
            // 
            // 
            // 
            // 
            this.Purchase_price.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.Purchase_price.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location2")));
            this.Purchase_price.CustomButton.Name = "";
            this.Purchase_price.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size2")));
            this.Purchase_price.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Purchase_price.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex2")));
            this.Purchase_price.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Purchase_price.CustomButton.UseSelectable = true;
            this.Purchase_price.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible2")));
            this.Purchase_price.Lines = new string[0];
            resources.ApplyResources(this.Purchase_price, "Purchase_price");
            this.Purchase_price.MaxLength = 32767;
            this.Purchase_price.Name = "Purchase_price";
            this.Purchase_price.PasswordChar = '\0';
            this.Purchase_price.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Purchase_price.SelectedText = "";
            this.Purchase_price.SelectionLength = 0;
            this.Purchase_price.SelectionStart = 0;
            this.Purchase_price.ShortcutsEnabled = true;
            this.Purchase_price.UseSelectable = true;
            this.Purchase_price.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Purchase_price.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.Purchase_price.Click += new System.EventHandler(this.metroTextBox2_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Navy;
            this.btn_close.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_close.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_close.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            resources.ApplyResources(this.btn_close, "btn_close");
            this.btn_close.Name = "btn_close";
            this.btn_close.UseCustomBackColor = true;
            this.btn_close.UseCustomForeColor = true;
            this.btn_close.UseSelectable = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // combobox_pcategory
            // 
            this.combobox_pcategory.FormattingEnabled = true;
            resources.ApplyResources(this.combobox_pcategory, "combobox_pcategory");
            this.combobox_pcategory.Name = "combobox_pcategory";
            // 
            // combobox_psupplier
            // 
            this.combobox_psupplier.FormattingEnabled = true;
            resources.ApplyResources(this.combobox_psupplier, "combobox_psupplier");
            this.combobox_psupplier.Name = "combobox_psupplier";
            this.combobox_psupplier.SelectedIndexChanged += new System.EventHandler(this.combobox_psupplier_SelectedIndexChanged);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Navy;
            this.metroPanel1.Controls.Add(this.label4);
            this.metroPanel1.Controls.Add(this.pictureBox2);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            resources.ApplyResources(this.metroPanel1, "metroPanel1");
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Name = "label4";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.metroTextBox1.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location3")));
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size3")));
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex3")));
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible3")));
            this.metroTextBox1.Lines = new string[0];
            resources.ApplyResources(this.metroTextBox1, "metroTextBox1");
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox1.TextChanged += new System.EventHandler(this.metroTextBox1_TextChanged);
            this.metroTextBox1.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // metroLabel1
            // 
            resources.ApplyResources(this.metroLabel1, "metroLabel1");
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseCustomForeColor = true;
            // 
            // DefineProductScreen
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroTextBox1);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.combobox_psupplier);
            this.Controls.Add(this.combobox_pcategory);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.Purchase_price);
            this.Controls.Add(this.Sales_price);
            this.Controls.Add(this.lbl_sprice);
            this.Controls.Add(this.lbl_costprice);
            this.Controls.Add(this.lbl_psupplier);
            this.Controls.Add(this.lbl_pcategory);
            this.Controls.Add(this.lbl_pname);
            this.Controls.Add(this.txt_pname);
            this.Controls.Add(this.Metro_Gridview);
            this.Controls.Add(this.btn_save);
            this.Movable = false;
            this.Name = "DefineProductScreen";
            this.Resizable = false;
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.DefineProductScreen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Metro_Gridview)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton btn_save;
        private MetroFramework.Controls.MetroGrid Metro_Gridview;
        private MetroFramework.Controls.MetroTextBox txt_pname;
        private MetroFramework.Controls.MetroLabel lbl_pname;
        private MetroFramework.Controls.MetroLabel lbl_pcategory;
        private MetroFramework.Controls.MetroLabel lbl_psupplier;
        private MetroFramework.Controls.MetroLabel lbl_costprice;
        private MetroFramework.Controls.MetroLabel lbl_sprice;
        private MetroFramework.Controls.MetroTextBox Sales_price;
        private MetroFramework.Controls.MetroTextBox Purchase_price;
        private MetroFramework.Controls.MetroButton btn_close;
        private System.Windows.Forms.ComboBox combobox_pcategory;
        private System.Windows.Forms.ComboBox combobox_psupplier;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using IT4SolutionPointOfSalesSoftware.General;

namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    public partial class Change_Password : MetroFramework.Forms.MetroForm
    {
        public Change_Password()
        {
            InitializeComponent();
        }

        private void Change_Password_Load(object sender, EventArgs e)
        {

        }

        private void btn_change_password_Click(object sender, EventArgs e)
        {
            if (txt_username.Text.Length > 0 || txt_old_password.Text.Length > 0 ||txt_new_password.Text.Length > 0 || txt_confirm_password.Text.Length > 0)
            {
                if (txt_confirm_password.Text.Equals(txt_new_password.Text))
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                        {
                            using (SqlCommand cmd = new SqlCommand("change_passwordadmin", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@username", txt_username.Text);
                                cmd.Parameters.AddWithValue("@old_password", txt_old_password.Text);
                                cmd.Parameters.AddWithValue("@new_password", txt_new_password.Text);
                                cmd.Parameters.Add("@ret", SqlDbType.Int);
                                cmd.Parameters["@ret"].Direction = ParameterDirection.Output;

                                con.Open();
                                int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                                int ret = Convert.ToInt32(cmd.Parameters["@ret"].Value);
                                if (ret > 0)
                                {
                                    MessageBox.Show("Password Is Updated !   ");
                                    btn_change_password.Enabled = false;
                                    txt_username.Text = "";
                                    txt_old_password.Text = "";
                                    txt_new_password.Text = "";
                                    txt_confirm_password.Text = "";


                                }
                                else
                                {
                                    MessageBox.Show("Password Is Not Updated ! You Have Not Entered Correct Username Or Password try again....");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Contact Administrartor");
                    }
                }
                else
                {
                    MessageBox.Show("Confirm Password Must Be Match With New Password");
                }
            }
            else
            {
                MessageBox.Show("Fill All The Text Boxes");
            }
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {

            this.Dispose();
            DashboardForm fd = new DashboardForm();
            fd.Show();
        }
    }
}

﻿namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    partial class ProductsRecordForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductsRecordForms));
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txt_Product_Name = new MetroFramework.Controls.MetroTextBox();
            this.Search_grid = new MetroFramework.Controls.MetroGrid();
            this.close = new MetroFramework.Controls.MetroButton();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Search_grid)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(23, 79);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(173, 25);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Search your product";
            this.metroLabel1.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // txt_Product_Name
            // 
            // 
            // 
            // 
            this.txt_Product_Name.CustomButton.Image = null;
            this.txt_Product_Name.CustomButton.Location = new System.Drawing.Point(597, 1);
            this.txt_Product_Name.CustomButton.Name = "";
            this.txt_Product_Name.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txt_Product_Name.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_Product_Name.CustomButton.TabIndex = 1;
            this.txt_Product_Name.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_Product_Name.CustomButton.UseSelectable = true;
            this.txt_Product_Name.CustomButton.Visible = false;
            this.txt_Product_Name.Lines = new string[0];
            this.txt_Product_Name.Location = new System.Drawing.Point(23, 107);
            this.txt_Product_Name.MaxLength = 32767;
            this.txt_Product_Name.Name = "txt_Product_Name";
            this.txt_Product_Name.PasswordChar = '\0';
            this.txt_Product_Name.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_Product_Name.SelectedText = "";
            this.txt_Product_Name.SelectionLength = 0;
            this.txt_Product_Name.SelectionStart = 0;
            this.txt_Product_Name.ShortcutsEnabled = true;
            this.txt_Product_Name.Size = new System.Drawing.Size(619, 23);
            this.txt_Product_Name.TabIndex = 1;
            this.txt_Product_Name.UseSelectable = true;
            this.txt_Product_Name.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_Product_Name.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txt_Product_Name.Click += new System.EventHandler(this.txt_Product_Name_Click);
            // 
            // Search_grid
            // 
            this.Search_grid.AllowUserToAddRows = false;
            this.Search_grid.AllowUserToDeleteRows = false;
            this.Search_grid.AllowUserToResizeRows = false;
            this.Search_grid.BackgroundColor = System.Drawing.Color.Navy;
            this.Search_grid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Search_grid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.Search_grid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Search_grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Search_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Search_grid.DefaultCellStyle = dataGridViewCellStyle2;
            this.Search_grid.EnableHeadersVisualStyles = false;
            this.Search_grid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.Search_grid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Search_grid.Location = new System.Drawing.Point(23, 136);
            this.Search_grid.Name = "Search_grid";
            this.Search_grid.ReadOnly = true;
            this.Search_grid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Search_grid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Search_grid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Search_grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Search_grid.Size = new System.Drawing.Size(619, 275);
            this.Search_grid.TabIndex = 2;
            this.Search_grid.UseCustomBackColor = true;
            this.Search_grid.UseCustomForeColor = true;
            this.Search_grid.UseStyleColors = true;
            this.Search_grid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Search_grid_CellContentClick);
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.Navy;
            this.close.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.close.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.close.ForeColor = System.Drawing.SystemColors.Window;
            this.close.Location = new System.Drawing.Point(556, 417);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(86, 32);
            this.close.TabIndex = 3;
            this.close.Text = "Close";
            this.close.UseCustomBackColor = true;
            this.close.UseCustomForeColor = true;
            this.close.UseSelectable = true;
            this.close.UseStyleColors = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Navy;
            this.metroPanel1.Controls.Add(this.label4);
            this.metroPanel1.Controls.Add(this.pictureBox2);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(0, 2);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(782, 62);
            this.metroPanel1.TabIndex = 8;
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(192, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(218, 31);
            this.label4.TabIndex = 4;
            this.label4.Text = "#Product Record";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(122, -5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(73, 67);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // ProductsRecordForms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 469);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.close);
            this.Controls.Add(this.Search_grid);
            this.Controls.Add(this.txt_Product_Name);
            this.Controls.Add(this.metroLabel1);
            this.Movable = false;
            this.Name = "ProductsRecordForms";
            this.Resizable = false;
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.ProductsRecordForms_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Search_grid)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txt_Product_Name;
        private MetroFramework.Controls.MetroGrid Search_grid;
        private MetroFramework.Controls.MetroButton close;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
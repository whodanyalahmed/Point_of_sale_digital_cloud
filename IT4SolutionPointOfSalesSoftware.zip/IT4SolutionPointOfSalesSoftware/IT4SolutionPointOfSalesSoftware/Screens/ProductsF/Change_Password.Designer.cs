﻿namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    partial class Change_Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Change_Password));
            this.txt_username = new MetroFramework.Controls.MetroTextBox();
            this.txt_old_password = new MetroFramework.Controls.MetroTextBox();
            this.txt_new_password = new MetroFramework.Controls.MetroTextBox();
            this.txt_confirm_password = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.btn_change_password = new MetroFramework.Controls.MetroButton();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_username
            // 
            // 
            // 
            // 
            this.txt_username.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.txt_username.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location")));
            this.txt_username.CustomButton.Name = "";
            this.txt_username.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size")));
            this.txt_username.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_username.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex")));
            this.txt_username.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_username.CustomButton.UseSelectable = true;
            this.txt_username.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible")));
            this.txt_username.Lines = new string[0];
            resources.ApplyResources(this.txt_username, "txt_username");
            this.txt_username.MaxLength = 32767;
            this.txt_username.Name = "txt_username";
            this.txt_username.PasswordChar = '\0';
            this.txt_username.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_username.SelectedText = "";
            this.txt_username.SelectionLength = 0;
            this.txt_username.SelectionStart = 0;
            this.txt_username.ShortcutsEnabled = true;
            this.txt_username.UseSelectable = true;
            this.txt_username.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_username.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txt_old_password
            // 
            // 
            // 
            // 
            this.txt_old_password.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.txt_old_password.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location1")));
            this.txt_old_password.CustomButton.Name = "";
            this.txt_old_password.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size1")));
            this.txt_old_password.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_old_password.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex1")));
            this.txt_old_password.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_old_password.CustomButton.UseSelectable = true;
            this.txt_old_password.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible1")));
            this.txt_old_password.Lines = new string[0];
            resources.ApplyResources(this.txt_old_password, "txt_old_password");
            this.txt_old_password.MaxLength = 32767;
            this.txt_old_password.Name = "txt_old_password";
            this.txt_old_password.PasswordChar = '*';
            this.txt_old_password.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_old_password.SelectedText = "";
            this.txt_old_password.SelectionLength = 0;
            this.txt_old_password.SelectionStart = 0;
            this.txt_old_password.ShortcutsEnabled = true;
            this.txt_old_password.UseSelectable = true;
            this.txt_old_password.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_old_password.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txt_new_password
            // 
            // 
            // 
            // 
            this.txt_new_password.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.txt_new_password.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location2")));
            this.txt_new_password.CustomButton.Name = "";
            this.txt_new_password.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size2")));
            this.txt_new_password.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_new_password.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex2")));
            this.txt_new_password.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_new_password.CustomButton.UseSelectable = true;
            this.txt_new_password.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible2")));
            this.txt_new_password.Lines = new string[0];
            resources.ApplyResources(this.txt_new_password, "txt_new_password");
            this.txt_new_password.MaxLength = 32767;
            this.txt_new_password.Name = "txt_new_password";
            this.txt_new_password.PasswordChar = '*';
            this.txt_new_password.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_new_password.SelectedText = "";
            this.txt_new_password.SelectionLength = 0;
            this.txt_new_password.SelectionStart = 0;
            this.txt_new_password.ShortcutsEnabled = true;
            this.txt_new_password.UseSelectable = true;
            this.txt_new_password.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_new_password.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txt_confirm_password
            // 
            // 
            // 
            // 
            this.txt_confirm_password.CustomButton.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.txt_confirm_password.CustomButton.Location = ((System.Drawing.Point)(resources.GetObject("resource.Location3")));
            this.txt_confirm_password.CustomButton.Name = "";
            this.txt_confirm_password.CustomButton.Size = ((System.Drawing.Size)(resources.GetObject("resource.Size3")));
            this.txt_confirm_password.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_confirm_password.CustomButton.TabIndex = ((int)(resources.GetObject("resource.TabIndex3")));
            this.txt_confirm_password.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_confirm_password.CustomButton.UseSelectable = true;
            this.txt_confirm_password.CustomButton.Visible = ((bool)(resources.GetObject("resource.Visible3")));
            this.txt_confirm_password.Lines = new string[0];
            resources.ApplyResources(this.txt_confirm_password, "txt_confirm_password");
            this.txt_confirm_password.MaxLength = 32767;
            this.txt_confirm_password.Name = "txt_confirm_password";
            this.txt_confirm_password.PasswordChar = '*';
            this.txt_confirm_password.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_confirm_password.SelectedText = "";
            this.txt_confirm_password.SelectionLength = 0;
            this.txt_confirm_password.SelectionStart = 0;
            this.txt_confirm_password.ShortcutsEnabled = true;
            this.txt_confirm_password.UseSelectable = true;
            this.txt_confirm_password.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_confirm_password.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            resources.ApplyResources(this.metroLabel1, "metroLabel1");
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Name = "metroLabel1";
            // 
            // metroLabel2
            // 
            resources.ApplyResources(this.metroLabel2, "metroLabel2");
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Name = "metroLabel2";
            // 
            // metroLabel3
            // 
            resources.ApplyResources(this.metroLabel3, "metroLabel3");
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Name = "metroLabel3";
            // 
            // metroLabel4
            // 
            resources.ApplyResources(this.metroLabel4, "metroLabel4");
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Name = "metroLabel4";
            // 
            // btn_change_password
            // 
            this.btn_change_password.BackColor = System.Drawing.Color.Navy;
            this.btn_change_password.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_change_password.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_change_password.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_change_password, "btn_change_password");
            this.btn_change_password.Name = "btn_change_password";
            this.btn_change_password.UseCustomBackColor = true;
            this.btn_change_password.UseCustomForeColor = true;
            this.btn_change_password.UseSelectable = true;
            this.btn_change_password.UseStyleColors = true;
            this.btn_change_password.Click += new System.EventHandler(this.btn_change_password_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Navy;
            this.metroPanel1.Controls.Add(this.pictureBox4);
            this.metroPanel1.Controls.Add(this.label4);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            resources.ApplyResources(this.metroPanel1, "metroPanel1");
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox4, "pictureBox4");
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.TabStop = false;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Name = "label4";
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.Navy;
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.metroButton1, "metroButton1");
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // Change_Password
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.btn_change_password);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.txt_confirm_password);
            this.Controls.Add(this.txt_new_password);
            this.Controls.Add(this.txt_old_password);
            this.Controls.Add(this.txt_username);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Change_Password";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.Change_Password_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox txt_username;
        private MetroFramework.Controls.MetroTextBox txt_old_password;
        private MetroFramework.Controls.MetroTextBox txt_new_password;
        private MetroFramework.Controls.MetroTextBox txt_confirm_password;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroButton btn_change_password;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.Label label4;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}
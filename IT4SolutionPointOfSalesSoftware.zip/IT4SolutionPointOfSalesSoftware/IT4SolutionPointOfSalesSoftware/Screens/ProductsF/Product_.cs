﻿using IT4SolutionPointOfSalesSoftware.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    public partial class Product_ : MetroFramework.Forms.MetroForm
    {
        public Product_()
        {
            InitializeComponent();
        }
        int getProductCategory_Id = -1;
        private void Product__Load(object sender, EventArgs e)
        {
            GetData();
        }
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            grid_Product.DataSource = null;
            grid_Product.Rows.Clear();
            grid_Product.Columns.Clear();
            try
            {
                using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("Select * from Product_Category", con))
                    {
                        con.Open();
                        SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                        adpt.Fill(dt);
                        grid_Product.DataSource = dt;
                        addButton();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



            return dt;
        }
        void addButton()
        {
            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            grid_Product.Columns.Add(btn);
            btn.HeaderText = "View Data";
            btn.Text = "Display";
            btn.Name = "btn";
            btn.UseColumnTextForButtonValue = true;
        }
        private void btn_click_Prodct_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("Ips_Product_Category", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Product_Name", txt_productCategory.Text);
                        cmd.Parameters.Add("@ret", SqlDbType.Int);
                        cmd.Parameters["@ret"].Direction = ParameterDirection.Output;

                        con.Open();
                        int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                        int ret = Convert.ToInt32(cmd.Parameters["@ret"].Value);
                        if (ret > 0)
                        {
                            MessageBox.Show("Product Category Is Inserted !   ");
                        }
                        else
                        {
                            MessageBox.Show("Product Category Is Not Inserted !   try again....");
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Product Category With The Name "+ txt_productCategory.Text +" Is Already Inserted");
            }
        }

        private void grid_Product_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int Row = e.RowIndex;
            if(Row>-1&&(Row+1)!=grid_Product.Rows.Count)
            {
                metroButton1.Enabled = true;
                txt_productCategory.Text =  grid_Product.Rows[Row].Cells[1].Value.ToString();
                getProductCategory_Id = Convert.ToInt32(grid_Product.Rows[Row].Cells[0].Value.ToString());
            }
            else
            {

                metroButton1.Enabled = false;
            }
        }

        private void grid_Product_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            
        }

        private void grid_Product_SelectionChanged(object sender, EventArgs e)
        {
           
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            if (txt_productCategory.Text.Length > 0)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("ups_Product_Category", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@Product_Name", txt_productCategory.Text);
                            cmd.Parameters.AddWithValue("@Product_CategoryID", getProductCategory_Id);
                            cmd.Parameters.Add("@ret", SqlDbType.Int);
                            cmd.Parameters["@ret"].Direction = ParameterDirection.Output;

                            con.Open();
                            int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                            int ret = Convert.ToInt32(cmd.Parameters["@ret"].Value);
                            if (ret > 0)
                            {
                                MessageBox.Show("Product Category Is Updated !   ");
                                metroButton1.Enabled = false;
                                txt_productCategory.Text = "";
                                GetData();
                            }
                            else
                            {
                                MessageBox.Show("Product Category Is Not Inserted !   try again....");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Product Category With The Name " + txt_productCategory.Text + " Is Already Inserted");
                }
            }
            else
            {
                MessageBox.Show("Product Category Name Should Not Be Null");
            }
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DashboardForm fod = new DashboardForm();
            fod.Show();
        }
    }
}

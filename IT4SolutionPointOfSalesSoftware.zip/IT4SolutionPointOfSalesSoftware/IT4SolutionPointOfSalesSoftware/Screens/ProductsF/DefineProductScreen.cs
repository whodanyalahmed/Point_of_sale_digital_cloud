﻿using IT4SolutionPointOfSalesSoftware.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    public partial class DefineProductScreen : MetroFramework.Forms.MetroForm
    {
        public DefineProductScreen()
        {
            InitializeComponent();
            comboboxDataFill();
            comboboxdataSupplier();

        }
        List<String> categoryID = new List<string>();
        List<String> supplierID = new List<string>();
        void comboboxDataFill()
        {
            combobox_pcategory.Items.Clear();
            categoryID.Clear();
            combobox_pcategory.Items.Add("Select Product Category");
            categoryID.Add("Select Product Category");
            combobox_pcategory.SelectedIndex = 0;
            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from Product_Category", con))
                {
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        combobox_pcategory.Items.Add(sdr["Product_Name"].ToString());
                        categoryID.Add(sdr["Product_CategoryID"].ToString());

                    }

                }
            }

        }
        void comboboxdataSupplier()
        {
            combobox_psupplier.Items.Clear();
            supplierID.Clear();
            combobox_psupplier.Items.Add("Select Supplier Name");
            supplierID.Add("Select Supplier Name");
            combobox_psupplier.SelectedIndex = 0;
            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from supplier", con))
                {
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        combobox_psupplier.Items.Add(sdr["Supplier Name"].ToString());
                        supplierID.Add(sdr["SupplierID"].ToString());

                    }

                }
            }
        }
        public bool IsUpdate
        {
            get;
            set;
        }
        private void DefineProductScreen_Load(object sender, EventArgs e)
        {
            if (!this.IsUpdate)
            {
               
            }
            loadAllSizesDataGridView();


        }


        private DataTable GetComboBoxData(int ListTypeID)
        {
            DataTable tdRecord = new DataTable();
            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_ListTypeData_LoadDataIntoComboBox", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@listTypeID", ListTypeID);
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    tdRecord.Load(sdr);
                }
            }
            return tdRecord;
        }

        private void loadAllSizesDataGridView()
        {
            Metro_Gridview.DataSource = GetSizesData();
          


        }




        private DataTable GetSizesData()
        {
            DataTable dtsizes = new DataTable();

            using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_Sizes_LoadAllSizes", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;          
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtsizes.Load(sdr);


                }
            }

                return dtsizes;
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                int getCombo_ProductID = combobox_pcategory.SelectedIndex;
                int getCombo_ProductID1 = combobox_psupplier.SelectedIndex;

                if (getCombo_ProductID > 0 && getCombo_ProductID1 > 0)
                {
                    try
                    {
                        Double purcsePrice = Convert.ToDouble(Purchase_price.Text);
                        Double salePrice = Convert.ToDouble(Sales_price.Text);
                        using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                        {
                            using (SqlCommand cmd = new SqlCommand("usp_products_insertNewProduct", con))
                            {

                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@Name", txt_pname.Text);
                                cmd.Parameters.AddWithValue("@CategoryID", categoryID[getCombo_ProductID].ToString());
                                cmd.Parameters.AddWithValue("@SupplieID", supplierID[getCombo_ProductID1].ToString());
                                cmd.Parameters.AddWithValue("@PurchasePrice", purcsePrice);
                                cmd.Parameters.AddWithValue("@SalesPrice", salePrice);



                                cmd.Parameters.Add("@ret", SqlDbType.Int);
                                cmd.Parameters["@ret"].Direction = ParameterDirection.Output;
                                con.Open();
                                cmd.ExecuteNonQuery();
                                int ret = Convert.ToInt32(cmd.Parameters["@ret"].Value);
                                if (ret > 0)
                                {
                                    MessageBox.Show("Product is successfully saved...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    loadAllSizesDataGridView();
                                }
                                else
                                {
                                    MessageBox.Show("Product is Not Inserted...", "error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                                }
                                con.Close();
                            }
                        }
                    }

                    catch(Exception ex)
                    {
                        MessageBox.Show("Product Price Or Product Sale  is Not Accurate...", "error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Product Category Or Product Supplier is Not Selected...", "error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);

                }
            }
        }


        private bool isValid()
        {
            if(txt_pname.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Product name is required..","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txt_pname.Focus();
                return false;
            }
            
            if (Purchase_price.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Purchase Price is required..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Purchase_price.Focus();
                return false;
            }

            if (combobox_pcategory.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Product Category is required..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                combobox_pcategory.Focus();
                return false;
            }

            if (combobox_psupplier.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Product Supplier is required..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                combobox_psupplier.Focus();
                return false;
            }


            return true;

        }

        private void btn_define_new_Click(object sender, EventArgs e)
        {
            clearControls();
        }

        private void clearControls()
        {
            txt_pname.Clear();
            combobox_psupplier.SelectedIndex = -1;
            combobox_pcategory.SelectedIndex = -1;
            Purchase_price.Clear();
            Sales_price.Clear();


            foreach(DataGridViewRow row in Metro_Gridview.Rows)
            {
                row.Cells["Select"].Value = 0;
            }
            txt_pname.Focus();
        }

        private void metroTextBox2_Click(object sender, EventArgs e)
        {

        }

        private void txt_pname_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click_1(object sender, EventArgs e)
        {

        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DashboardForm df = new DashboardForm();
            df.Show();
        }

        private void metroComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Product_Category_Click(object sender, EventArgs e)
        {

        }

        private void Metro_Gridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lbl_pname_Click(object sender, EventArgs e)
        {


        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {
    

        }

        private void metroTextBox1_TextChanged(object sender, EventArgs e)
        {
            (Metro_Gridview.DataSource as DataTable).DefaultView.RowFilter = string.Format("[Product Name] like '%{0}%'", metroTextBox1.Text);
        }

        private void combobox_psupplier_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

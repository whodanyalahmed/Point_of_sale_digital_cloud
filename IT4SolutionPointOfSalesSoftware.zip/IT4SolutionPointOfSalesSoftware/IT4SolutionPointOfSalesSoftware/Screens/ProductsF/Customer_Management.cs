﻿using IT4SolutionPointOfSalesSoftware.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    public partial class Customer_Management : MetroFramework.Forms.MetroForm
    {
        private object getCustomerID;
        public Customer_Management()
        {
            InitializeComponent();
            GetData();
        }
      

        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            grid_customer.DataSource = null;
            grid_customer.Rows.Clear();
            grid_customer.Columns.Clear();
            try
            {
                using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("Select * from Customers", con))
                    {
                        con.Open();
                        SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                        adpt.Fill(dt);
                        grid_customer.DataSource = dt;
                        addButton();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



            return dt;
        }
        void addButton()
        {
            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            grid_customer.Columns.Add(btn);
            btn.HeaderText = "View Data";
            btn.Text = "Display";
            btn.Name = "btn";
            btn.UseColumnTextForButtonValue = true;
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DashboardForm fd = new DashboardForm();
            fd.Show();
        }

        private void btn_customerInsert_Click(object sender, EventArgs e)
        {
            try
            {

                using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("ips_customer", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Customer_Name", txt_customername.Text);
                        cmd.Parameters.AddWithValue("@Customer_Address", txt_customeraddress.Text);
                        cmd.Parameters.AddWithValue("@Customer_CellNo", txt_customerCell.Text);

                        cmd.Parameters.Add("@return", SqlDbType.Int);
                        cmd.Parameters["@return"].Direction = ParameterDirection.Output;

                        con.Open();
                        int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                        int ret = Convert.ToInt32(cmd.Parameters["@return"].Value);
                        if (ret > 0)
                        {
                            MessageBox.Show("Customer Details Is Inserted !   ");
                        }
                        else
                        {
                            MessageBox.Show("Customer Details Is Not Inserted !   try again....");
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(" CustomerName " + txt_customername.Text + " Is Already Inserted");
            }

        }
    

        private void txt_customername_Click(object sender, EventArgs e)
        {

        }

        private void grid_customer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int Row = e.RowIndex;
            if (Row > -1 && (Row + 1) != grid_customer.Rows.Count)
            {
                try {
                    btn_customerUpdate.Enabled = true;
                    txt_customername.Text = grid_customer.Rows[Row].Cells[2].Value.ToString();
                    txt_customeraddress.Text = grid_customer.Rows[Row].Cells[4].Value.ToString();
                    txt_customerCell.Text = grid_customer.Rows[Row].Cells[3].Value.ToString();

                    getCustomerID = grid_customer.Rows[Row].Cells[1].Value.ToString();
                }
                catch(Exception ex)
                {

                }
                }
            else
            {

                btn_customerUpdate.Enabled = false;
            }
        }

        private void btn_customerUpdate_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text.Length > 0)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("upl_customer", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@Customer_Name", txt_customername.Text);
                            cmd.Parameters.AddWithValue("@Customer_Address", txt_customeraddress.Text);
                            cmd.Parameters.AddWithValue("@Customer_CellNo", txt_customerCell.Text);
                            cmd.Parameters.AddWithValue("@CustomerID", getCustomerID);
                            cmd.Parameters.Add("@return", SqlDbType.Int);
                            cmd.Parameters["@return"].Direction = ParameterDirection.Output;

                            con.Open();
                            int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                            int ret = Convert.ToInt32(cmd.Parameters["@return"].Value);
                            if (ret > 0)
                            {
                                MessageBox.Show("Customer Information Is Updated !   ");
                                btn_customerUpdate.Enabled = false;
                                txt_customername.Text = "";
                                txt_customeraddress.Text = "";
                                txt_customerCell.Text = "";
                                GetData();

                            }
                            else
                            {
                                MessageBox.Show("No Customer Detail Is Updated !   try again....");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Customer Name " + txt_customername.Text + " Is Already Updated");
                }
            }
            else
            {
                MessageBox.Show("Customer Name Should Not Be Null");
            }
        }

        private void Customer_Management_Load(object sender, EventArgs e)
        {

        }
    }
    }

    


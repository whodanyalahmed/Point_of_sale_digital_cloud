﻿using ClosedXML.Excel;
using IT4SolutionPointOfSalesSoftware.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT4SolutionPointOfSalesSoftware.Screens.ProductsF
{
    public partial class ReportDisplay : MetroFramework.Forms.MetroForm
    {
        public ReportDisplay()
        {
            InitializeComponent();
            getData();
        }
        DataTable dt = new DataTable();

        void getData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("select pc.Product_Name as 'Product Category' , p.Name as 'Product Name',sp.[Supplier Name] , sp.Supplier_CellNo , p.PurchasePrice, p.SalesPrice from Product_Category pc ,Products p , supplier sp where pc.Product_CategoryID = p.CategoryID and p.SupplieID = sp.SupplierID;", con))
                    {
                        con.Open();
                        cmd.Connection = con;
                        SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                        adpt.Fill(dt);
                        Search_grid.DataSource = dt;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }


        public int getSupplierID { get; private set; }

        private void Search_grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void close_Click(object sender, EventArgs e)
        {
           
            this.Hide();
            DashboardForm df = new DashboardForm();
            df.Show();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            DialogResult res = folderBrowserDialog1.ShowDialog();

            if (res == DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog1.SelectedPath))
            {
                String path = folderBrowserDialog1.SelectedPath.ToString();
                string fileName = txt_Product_Name.Text.ToString();
                using (XLWorkbook wb = new XLWorkbook())
                {
                    wb.Worksheets.Add(dt, fileName);
                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(path + "\\" + fileName + ".xlsx");
                        MessageBox.Show(fileName + " has been created on " + path);
                    }
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}

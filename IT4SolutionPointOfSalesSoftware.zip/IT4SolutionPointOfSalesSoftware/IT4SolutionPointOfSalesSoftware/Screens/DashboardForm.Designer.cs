﻿namespace IT4SolutionPointOfSalesSoftware.Screens
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardForm));
            this.btn_1 = new MetroFramework.Controls.MetroButton();
            this.btn_2 = new MetroFramework.Controls.MetroButton();
            this.btn_4 = new MetroFramework.Controls.MetroButton();
            this.btn_3 = new MetroFramework.Controls.MetroButton();
            this.btn_10 = new MetroFramework.Controls.MetroButton();
            this.btn_9 = new MetroFramework.Controls.MetroButton();
            this.btn_5 = new MetroFramework.Controls.MetroButton();
            this.btn_supplier = new MetroFramework.Controls.MetroButton();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Dashboard = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.Color.Navy;
            this.btn_1.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_1.DisplayFocus = true;
            this.btn_1.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_1.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_1, "btn_1");
            this.btn_1.Name = "btn_1";
            this.btn_1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btn_1.UseCustomBackColor = true;
            this.btn_1.UseCustomForeColor = true;
            this.btn_1.UseSelectable = true;
            this.btn_1.UseStyleColors = true;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.Color.Navy;
            this.btn_2.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_2.DisplayFocus = true;
            this.btn_2.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_2.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_2.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_2, "btn_2");
            this.btn_2.Name = "btn_2";
            this.btn_2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btn_2.UseCustomBackColor = true;
            this.btn_2.UseCustomForeColor = true;
            this.btn_2.UseSelectable = true;
            this.btn_2.UseStyleColors = true;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.Color.Navy;
            this.btn_4.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_4.DisplayFocus = true;
            this.btn_4.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_4.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_4.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_4, "btn_4");
            this.btn_4.Name = "btn_4";
            this.btn_4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btn_4.UseCustomBackColor = true;
            this.btn_4.UseCustomForeColor = true;
            this.btn_4.UseSelectable = true;
            this.btn_4.UseStyleColors = true;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.Color.Navy;
            this.btn_3.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_3.DisplayFocus = true;
            this.btn_3.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_3.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_3.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_3, "btn_3");
            this.btn_3.Name = "btn_3";
            this.btn_3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btn_3.UseCustomBackColor = true;
            this.btn_3.UseCustomForeColor = true;
            this.btn_3.UseSelectable = true;
            this.btn_3.UseStyleColors = true;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // btn_10
            // 
            this.btn_10.BackColor = System.Drawing.Color.Navy;
            this.btn_10.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_10.DisplayFocus = true;
            this.btn_10.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_10.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_10.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_10, "btn_10");
            this.btn_10.Name = "btn_10";
            this.btn_10.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btn_10.UseCustomBackColor = true;
            this.btn_10.UseCustomForeColor = true;
            this.btn_10.UseSelectable = true;
            this.btn_10.UseStyleColors = true;
            this.btn_10.Click += new System.EventHandler(this.btn_10_Click);
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.Color.Navy;
            this.btn_9.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_9.DisplayFocus = true;
            this.btn_9.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_9.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_9.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_9, "btn_9");
            this.btn_9.Name = "btn_9";
            this.btn_9.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btn_9.UseCustomBackColor = true;
            this.btn_9.UseCustomForeColor = true;
            this.btn_9.UseSelectable = true;
            this.btn_9.UseStyleColors = true;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.Color.Navy;
            this.btn_5.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_5.DisplayFocus = true;
            this.btn_5.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_5.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_5.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_5, "btn_5");
            this.btn_5.Name = "btn_5";
            this.btn_5.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btn_5.UseCustomBackColor = true;
            this.btn_5.UseCustomForeColor = true;
            this.btn_5.UseSelectable = true;
            this.btn_5.UseStyleColors = true;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_supplier
            // 
            this.btn_supplier.BackColor = System.Drawing.Color.Navy;
            this.btn_supplier.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_supplier.DisplayFocus = true;
            this.btn_supplier.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btn_supplier.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btn_supplier.ForeColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.btn_supplier, "btn_supplier");
            this.btn_supplier.Name = "btn_supplier";
            this.btn_supplier.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btn_supplier.UseCustomBackColor = true;
            this.btn_supplier.UseCustomForeColor = true;
            this.btn_supplier.UseSelectable = true;
            this.btn_supplier.UseStyleColors = true;
            this.btn_supplier.Click += new System.EventHandler(this.btn_supplier_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Navy;
            this.metroPanel1.Controls.Add(this.pictureBox1);
            this.metroPanel1.Controls.Add(this.Dashboard);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            resources.ApplyResources(this.metroPanel1, "metroPanel1");
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // Dashboard
            // 
            resources.ApplyResources(this.Dashboard, "Dashboard");
            this.Dashboard.ForeColor = System.Drawing.SystemColors.Window;
            this.Dashboard.Name = "Dashboard";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox6, "pictureBox6");
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox8, "pictureBox8");
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox9, "pictureBox9");
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox10, "pictureBox10");
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox11, "pictureBox11");
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.pictureBox12, "pictureBox12");
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.TabStop = false;
            // 
            // DashboardForm
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.btn_supplier);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_10);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.Name = "DashboardForm";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.DashboardForm_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroButton btn_define_product;
        private MetroFramework.Controls.MetroButton btn_manage_products;
        private MetroFramework.Controls.MetroButton btn_manage_categories;
        private MetroFramework.Controls.MetroButton btn_stock_management;
        private MetroFramework.Controls.MetroButton btn_change_password;
        private MetroFramework.Controls.MetroButton btn_orders_records;
        private MetroFramework.Controls.MetroButton btn_exit_application;
        private MetroFramework.Controls.MetroButton btn_custom_reports;
        private MetroFramework.Controls.MetroButton btn_customers_management;
        private MetroFramework.Controls.MetroButton btn_add_new_sales_order;
        private MetroFramework.Controls.MetroButton btn_1;
        private MetroFramework.Controls.MetroButton btn_2;
        private MetroFramework.Controls.MetroButton btn_4;
        private MetroFramework.Controls.MetroButton btn_3;
        private MetroFramework.Controls.MetroButton btn_10;
        private MetroFramework.Controls.MetroButton btn_9;
        private MetroFramework.Controls.MetroButton btn_5;
        private MetroFramework.Controls.MetroButton btn_supplier;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.Label Dashboard;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
    }
}
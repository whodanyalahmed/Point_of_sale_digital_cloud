﻿using IT4SolutionPointOfSalesSoftware.Screens.ProductsF;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT4SolutionPointOfSalesSoftware.Screens
{
    public partial class DashboardForm : MetroFramework.Forms.MetroForm
    {
        public DashboardForm()
        {
            InitializeComponent();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            DefineProductScreen dps = new DefineProductScreen();
            dps.Show();

            this.Dispose();
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            ProductsRecordForms prd = new ProductsRecordForms();
            prd.Show();
            this.Dispose();
        }

        private void btn_supplier_Click(object sender, EventArgs e)
        {
            Supplier_Detail sd = new Supplier_Detail();
            sd.Show();
            this.Dispose();
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            Change_Password dps = new Change_Password();
            dps.Show();

            this.Dispose();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            Customer_Management dps = new Customer_Management();
            dps.Show();

            this.Dispose();
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            Product_ sd = new Product_();
            sd.Show();
            this.Dispose();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            ReportDisplay reportDisplay = new ReportDisplay();
            reportDisplay.Show();
            this.Dispose();
        }

        private void btn_7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            Stock_Managment mg = new Stock_Managment();
            mg.Show();
            this.Dispose();
        }
    }
}

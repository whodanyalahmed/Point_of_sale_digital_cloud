﻿using IT4SolutionPointOfSalesSoftware.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using IT4SolutionPointOfSalesSoftware.Screens;

namespace IT4SolutionPointOfSalesSoftware
{
    public partial class LoginForm : MetroFramework.Forms.MetroForm
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (Isvalid())
            {
                using (SqlConnection con = new SqlConnection(ApplicationSetting.ConnectionString()))
                {
                    using(SqlCommand cmd = new SqlCommand("usp_Login_VerifyLoginDetails",con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("Username", UserName.Text.Trim());
                        cmd.Parameters.AddWithValue("Password", Password.Text.Trim());

                        con.Open();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        if(sdr.Read()){
                            this.Hide();
                            DashboardForm df = new DashboardForm();
                            df.Show();
                            df.Focus();
                        }
                        else
                        {
                            MessageBox.Show("Username or password is incorrect. ","Login Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private bool Isvalid()
        {
            if (UserName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Username Must Be Required!", "From Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                UserName.Focus();
                return false;
            }
            if (Password.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Password Must Be Required!", "From Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Password.Focus();
                return false;
            }
            return true;
        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {

        }

        private void UserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
